import { Pipe, PipeTransform } from '@angular/core';
import { analyzeAndValidateNgModules } from '@angular/compiler';

@Pipe({
  name: 'rev'
})
export class RevPipe implements PipeTransform {

  transform(value: string, args?: any): any {
    var arg = args[0];
    return value.split("").reverse().join(arg) ;
  }

}
